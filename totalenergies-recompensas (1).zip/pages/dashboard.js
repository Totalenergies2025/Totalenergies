export default function Dashboard() {
  return (
    <div>
      <h1>Painel do Usuário</h1>
      <p>Bem-vindo à sua conta TotalEnergies</p>
      <ul>
        <li>Saldo atual</li>
        <li>Rendimentos diários</li>
        <li>Histórico</li>
        <li>Depósito</li>
        <li>Retirada</li>
        <li>Link de convite</li>
      </ul>
    </div>
  )
}
