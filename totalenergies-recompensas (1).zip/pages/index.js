export default function Home() {
  return (
    <div>
      <h1>TotalEnergies Recompensas</h1>
      <p>Ganhe 15% de rendimento diário com investimento a partir de 10.000 Kz</p>
    </div>
  )
}
