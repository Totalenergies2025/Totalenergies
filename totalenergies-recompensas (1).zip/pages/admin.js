export default function AdminPanel() {
  return (
    <div>
      <h1>Painel Administrativo</h1>
      <p>Controle de pagamentos, usuários e saques</p>
    </div>
  )
}
