export default function Login() {
  return (
    <div>
      <h1>Entrar na TotalEnergies</h1>
      <form>
        <input type="email" placeholder="Email" required />
        <input type="password" placeholder="Senha" required />
        <button type="submit">Entrar</button>
      </form>
    </div>
  )
}
